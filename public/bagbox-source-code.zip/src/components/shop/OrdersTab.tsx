"use client";
import React, { useMemo, useState } from "react";
import { useShop } from "@/hooks/useShop";
import { useAuth } from "@/hooks/useAuth";
import {
  createParcel,
  returnParcel,
  steadLastError,
  fraudCheck,
  type FraudReport,
} from "@/lib/api";
import {
  uid,
  todayBn,
  codOf,
  totalQty,
  guessZone,
  zoneName,
  DEFAULT_SHIP,
  getZoneDeliveryFee,
  calculateOrderCod,
  toEnDigits,
  parseCustomerBlock,
  isActive,
  type Zone,
} from "@/lib/utils";
import { restoreInto, deductInto } from "@/lib/stock";
import type { Order, OrderItem, OrderStatus, Product } from "@/lib/types";
import { Btn, Card, Modal, Empty, inputCls, Field, Badge } from "@/components/ui";
import ProductImg from "@/components/shared/ProductImg";

const BN_STATUS: Record<string, string> = {
  Pending: "পেন্ডিং",
  Packed: "প্যাকড",
  Shipped: "স্টেডফাস্টে 🚚",
  Delivered: "ডেলিভারড ✅",
  Cancelled: "ক্যানসেল",
  Returned: "রিটার্ন",
};

const ALL_STATUS: OrderStatus[] = [
  "Pending",
  "Packed",
  "Shipped",
  "Delivered",
  "Cancelled",
  "Returned",
];

/* ---------------- Messenger Quick Reply ---------------- */
function QuickReply() {
  const { db } = useShop();
  const [q, setQ] = useState("");

  const hits = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (query.length < 2) return [];
    const words = query.split(/\s+/);
    return (db.products || [])
      .filter(Boolean)
      .filter(isActive)
      .map((p) => {
        const hay = (
          p.name +
          " " +
          p.code +
          " " +
          p.cat +
          " " +
          p.variants.map((v) => v.size + " " + v.color).join(" ")
        ).toLowerCase();
        const score = words.filter((w) => w.length > 1 && hay.includes(w)).length;
        return { p, score };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
  }, [db.products, q]);

  const makeReplyText = (p: Product) => {
    const lines = (p.variants || []).map(
      (v) => `• ${(v.color + " " + (v.size || "")).trim()}: ${v.qty > 0 ? "✅ স্টকে আছে" : "❌ স্টক শেষ"}`
    );
    const avail = (p.variants || []).some((v) => v.qty > 0);
    return `${avail ? `জী আপু, আমাদের ${p.name} ✅ স্টকে এভেইলেবল আছে!` : `দুঃখিত আপু, ${p.name} এখন স্টক আউট ❌`}\n${lines.join(
      "\n"
    )}\nদাম: ৳${p.sell}\nডেলিভারি চার্জ: ঢাকার ভেতর ৳${getZoneDeliveryFee(db.settings, "inside")}, ঢাকার বাইরে ৳${getZoneDeliveryFee(db.settings, "outside")}\n\nঅর্ডার করতে আপনার নাম, সম্পূর্ণ ঠিকানা ও মোবাইল নম্বর দিন 📩`;
  };

  const copyReply = async (t: string) => {
    try {
      await navigator.clipboard.writeText(t);
      alert("✅ মেসেজ কপি হয়েছে! ফেসবুকে পেস্ট করুন।");
    } catch {
      prompt("কপি করুন:", t);
    }
  };

  return (
    <Card className="mb-3 bg-stone-50/80 border-amber-900/15">
      <div className="flex items-center justify-between mb-1">
        <h3 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
          💬 ফেসবুক মেসেঞ্জার কুইক রিপ্লাই
        </h3>
        <span className="text-[11px] text-amber-800 bg-amber-100/60 px-2 py-0.5 rounded-full font-medium">
          কাস্টমার মেসেজ জেনারেটর
        </span>
      </div>
      <p className="text-xs text-stone-500 mb-2">
        কাস্টমার ফেসবুকে যে ব্যাগের খোঁজ করছেন তা লিখুন, সঙ্গে সঙ্গে রেডি মেসেজ পেয়ে যাবেন।
      </p>
      <input
        className={inputCls}
        placeholder="যেমন: শোল্ডার ব্যাগ, কালো টোট, BG-101..."
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      {hits.map(({ p }) => (
        <div key={p.id} className="mt-2 rounded-xl bg-white p-2.5 border border-stone-200 text-xs shadow-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-stone-900">{p.name} ({p.code})</span>
            <span className="font-black text-amber-800">৳{p.sell}</span>
          </div>
          <div className="mt-1 text-stone-500 flex flex-wrap gap-1">
            {p.variants.map((v) => (
              <span key={v.id} className="bg-stone-100 px-1.5 py-0.5 rounded text-[11px]">
                {v.color}: {v.qty > 0 ? `${v.qty} pcs` : "শেষ ❌"}
              </span>
            ))}
          </div>
          <Btn small color="green" className="mt-2 w-full" onClick={() => copyReply(makeReplyText(p))}>
            📋 রিপ্লাই মেসেজ কপি করুন
          </Btn>
        </div>
      ))}
    </Card>
  );
}

/* ---------------- Create Order Modal ---------------- */
function CreateOrderModal({ onClose }: { onClose: () => void }) {
  const { db, mutateAndSync, notify } = useShop();

  const [pasteText, setPasteText] = useState("");
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [zone, setZone] = useState<Zone>("outside");
  const [dcharge, setDcharge] = useState<number>(() =>
    getZoneDeliveryFee(db.settings, "outside")
  );
  const [note, setNote] = useState("");
  const [autoSendSteadfast, setAutoSendSteadfast] = useState(true);
  const [busy, setBusy] = useState(false);

  // Selected order items
  const [selectedItems, setSelectedItems] = useState<OrderItem[]>([]);
  // Item selector states
  const [pickPid, setPickPid] = useState(db.products[0]?.id || "");
  const pickedProd = db.products.find((p) => p.id === pickPid);
  const [pickVid, setPickVid] = useState(pickedProd?.variants[0]?.id || "");
  const pickedVar = pickedProd?.variants.find((v) => v.id === pickVid);
  const [pickPrice, setPickPrice] = useState(pickedProd?.sell?.toString() || "");
  const [pickQty, setPickQty] = useState(1);
  const [showProductPicker, setShowProductPicker] = useState(false);
  const [pickerSearch, setPickerSearch] = useState("");

  const filteredPickerProducts = useMemo(() => {
    return db.products.filter(isActive).filter((p) => {
      if (!pickerSearch.trim()) return true;
      const q = pickerSearch.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        p.cat.toLowerCase().includes(q)
      );
    });
  }, [db.products, pickerSearch]);

  // Fraud check modal
  const [fraudReport, setFraudReport] = useState<FraudReport | null>(null);
  const [fraudChecking, setFraudChecking] = useState(false);

  // Handle Smart Paste
  const handleSmartPaste = (raw: string) => {
    setPasteText(raw);
    if (!raw.trim()) return;

    const parsed = parseCustomerBlock(raw);
    if (parsed.name) setCustomer(parsed.name);
    if (parsed.phone) setPhone(parsed.phone);
    if (parsed.address) setAddress(parsed.address);
    if (parsed.zone) {
      setZone(parsed.zone);
      setDcharge(getZoneDeliveryFee(db.settings, parsed.zone as Zone));
    }
  };

  const handleZoneChange = (z: Zone) => {
    setZone(z);
    setDcharge(getZoneDeliveryFee(db.settings, z));
  };

  const addItem = () => {
    if (!pickedProd || !pickedVar) {
      alert("ব্যাগ ও ভ্যারিয়েন্ট নির্বাচন করুন");
      return;
    }
    if (pickedVar.qty <= 0) {
      if (!confirm("⚠️ এই কালার/সাইজের ব্যাগ স্টকে শেষ! তবুও কি অর্ডারে যোগ করবেন?")) return;
    }

    const price = +pickPrice || pickedProd.sell || 0;
    const existingIdx = selectedItems.findIndex(
      (it) => it.productId === pickedProd.id && it.variantId === pickedVar.id
    );

    const itemImg = pickedVar.img || pickedProd.img;

    const itemQty = Math.max(1, pickQty || 1);
    if (existingIdx >= 0) {
      setSelectedItems((prev) =>
        prev.map((it, idx) =>
          idx === existingIdx ? { ...it, qty: it.qty + itemQty } : it
        )
      );
    } else {
      setSelectedItems((prev) => [
        ...prev,
        {
          productId: pickedProd.id,
          variantId: pickedVar.id,
          productName: pickedProd.name,
          variantLabel: `${pickedVar.color} (${pickedVar.size})`,
          qty: itemQty,
          price,
          buy: pickedProd.buy,
          img: itemImg,
        },
      ]);
    }
  };

  const removeItem = (idx: number) => {
    setSelectedItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const itemsTotal = selectedItems.reduce((acc, it) => acc + it.price * it.qty, 0);
  const [customCod, setCustomCod] = useState<string>("");
  const totalCod = calculateOrderCod(itemsTotal, dcharge, customCod);

  const runFraudCheck = async () => {
    if (!phone) {
      alert("আগে কাস্টমারের ফোন নম্বর দিন");
      return;
    }
    setFraudChecking(true);
    try {
      const rep = await fraudCheck(phone);
      setFraudReport(rep);
    } catch {
      alert("ফ্রড চেক সংযোগ করা যায়নি");
    } finally {
      setFraudChecking(false);
    }
  };

  const submitOrder = async () => {
    if (!customer.trim()) {
      alert("কাস্টমারের নাম দিন");
      return;
    }
    const cleanPh = toEnDigits(phone).trim();
    if (!/^01\d{9}$/.test(cleanPh)) {
      alert("সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (01XXXXXXXXX)");
      return;
    }
    if (!address.trim()) {
      alert("কাস্টমারের ঠিকানা দিন");
      return;
    }
    if (selectedItems.length === 0) {
      alert("কমপক্ষে ১টি ব্যাগ অর্ডারে যোগ করুন");
      return;
    }

    setBusy(true);

    const orderId = "BG-" + Math.floor(1000 + Math.random() * 9000);
    const zKey = zone as "inside" | "sub" | "outside";
    const dcost = db.settings?.ship?.[zKey]?.cost ?? DEFAULT_SHIP[zKey]?.cost ?? 115;

    const newOrder: Order = {
      id: orderId,
      ts: Date.now(),
      date: todayBn(),
      customer: customer.trim(),
      phone: cleanPh,
      address: address.trim(),
      items: selectedItems,
      total: itemsTotal,
      cod: totalCod,
      zone,
      dcost,
      dcharge,
      status: "Pending",
      payment: "ক্যাশ অন ডেলিভারি (COD)",
      note: note.trim(),
    };

    // Auto-send to Steadfast if checked (Minipop workflow)
    let steadfastSuccess = false;
    if (autoSendSteadfast) {
      try {
        const parcelRes = await createParcel(newOrder);
        if (parcelRes) {
          newOrder.steadfastId = parcelRes.cid;
          newOrder.trackingCode = parcelRes.tracking;
          newOrder.status = "Shipped";
          steadfastSuccess = true;
        } else {
          const err = steadLastError();
          if (err) {
            alert(`⚠️ অর্ডার তৈরি হয়েছে, তবে স্টেডফাস্টে স্বয়ংক্রিয় পার্সেল পাঠানো যায়নি: ${err}\n\nআপনি অর্ডারের পাশে '🚚 স্টেডফাস্টে পাঠান' বাটনে চাপ দিয়ে যেকোনো সময় পাঠাতে পারবেন।`);
          }
        }
      } catch (err) {
        console.warn("Steadfast auto-send failed:", err);
      }
    }

    // Deduct stock inventory and save
    await mutateAndSync((d) => {
      deductInto(d, selectedItems);
      d.orders.unshift(newOrder);
      d.moves.unshift({
        id: uid(),
        date: todayBn(),
        text: `📦 অর্ডার তৈরি (${orderId}): ${customer} - ${selectedItems.map((it) => `${it.productName} [${it.variantLabel}] x${it.qty}`).join(", ")}`,
      });
    });

    if (steadfastSuccess) {
      alert(`🎉 অর্ডার (${orderId}) সফলভাবে তৈরি হয়েছে এবং স্টেডফাস্ট কুরিয়ারে স্বয়ংক্রিয়ভাবে পার্সেল বুক হয়েছে!\n\nConsignment ID: ${newOrder.steadfastId}\nTracking Code: ${newOrder.trackingCode || "N/A"}`);
    }

    notify(
      "নতুন অর্ডার তৈরি!",
      `${customer} এর অর্ডার (${orderId}) তৈরি হয়েছে। ${steadfastSuccess ? "স্টেডফাস্টে পার্সেল পাঠানো হয়েছে ✅" : ""}`
    );

    setBusy(false);
    onClose();
  };

  return (
    <Modal title="🧾 নতুন ফেসবুক অর্ডার তৈরি করুন" onClose={onClose}>
      <div className="space-y-3.5">
        {/* Smart Paste Box */}
        <div className="bg-amber-50/70 p-3 rounded-2xl border border-amber-900/20">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-black text-amber-950 flex items-center gap-1">
              📋 ফেসবুক চ্যাট স্মার্ট পেস্ট (Smart Paste)
            </span>
            <span className="text-[10px] bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded-full font-bold">
              নাম, ফোন ও ঠিকানা স্বয়ংক্রিয় আলাদা হবে
            </span>
          </div>
          <textarea
            rows={3}
            className="w-full text-xs rounded-xl border border-amber-900/20 bg-white p-2 text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-700"
            placeholder="ফেসবুক মেসেঞ্জারে কাস্টমারের পুরো মেসেজটা কপি করে এখানে পেস্ট করুন..."
            value={pasteText}
            onChange={(e) => handleSmartPaste(e.target.value)}
          />
        </div>

        {/* Customer Fields */}
        <div className="grid grid-cols-2 gap-2">
          <Field label="কাস্টমারের নাম *">
            <input
              className={inputCls}
              placeholder="সাদিয়া ইসলাম"
              value={customer}
              onChange={(e) => setCustomer(e.target.value)}
            />
          </Field>
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-700">মোবাইল নম্বর *</span>
              <button
                type="button"
                onClick={runFraudCheck}
                disabled={fraudChecking || !phone}
                className="text-[11px] font-bold text-amber-800 hover:text-amber-950 cursor-pointer"
              >
                {fraudChecking ? "চেক হচ্ছে..." : "🛡️ ফ্রড চেক"}
              </button>
            </div>
            <input
              className={inputCls}
              placeholder="01712345678"
              value={phone}
              onChange={(e) => setPhone(toEnDigits(e.target.value))}
            />
          </div>
        </div>

        {/* Address */}
        <Field label="সম্পূর্ণ ডেলিভারি ঠিকানা *">
          <input
            className={inputCls}
            placeholder="বাসা নং, রোড নং, এলাকা, থানা ও জেলা"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
        </Field>

        {/* Zone & Delivery Fee */}
        <div className="grid grid-cols-2 gap-2">
          <Field label="ডেলিভারি জোন">
            <select
              className={inputCls}
              value={zone}
              onChange={(e) => handleZoneChange(e.target.value as Zone)}
            >
              <option value="inside">
                ঢাকার ভেতর (৳{getZoneDeliveryFee(db.settings, "inside")})
              </option>
              <option value="sub">
                সাব-ঢাকা (৳{getZoneDeliveryFee(db.settings, "sub")})
              </option>
              <option value="outside">
                ঢাকার বাইরে (৳{getZoneDeliveryFee(db.settings, "outside")})
              </option>
            </select>
          </Field>
          <Field label="ডেলিভারি চার্জ (৳)">
            <input
              type="number"
              className={inputCls}
              value={dcharge}
              onChange={(e) => setDcharge(+e.target.value || 0)}
            />
          </Field>
        </div>

        {/* Visual Bag Selector (No dropdowns - Visual Card & Photo Picker) */}
        <div className="border-t border-stone-200 pt-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-stone-800">
              👜 ব্যাগ নির্বাচন ও আইটেম যোগ
            </span>
            <button
              type="button"
              onClick={() => setShowProductPicker(true)}
              className="text-xs font-bold text-amber-800 hover:text-amber-900 bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-xl border border-amber-300 transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>🔄 অন্য ব্যাগ নির্বাচন</span>
              <span className="text-[10px]">▼</span>
            </button>
          </div>

          {/* Active Product Card with Large Photo (No plain dropdowns) */}
          {pickedProd ? (
            <div
              onClick={() => setShowProductPicker(true)}
              className="flex items-center gap-3.5 bg-gradient-to-r from-amber-50 to-orange-50/70 hover:from-amber-100 hover:to-orange-100 p-3 rounded-2xl border-2 border-amber-600/50 hover:border-amber-700 cursor-pointer transition-all shadow-xs group"
              title="অন্য ব্যাগ পরিবর্তন করতে চাপুন"
            >
              <div className="relative shrink-0">
                <ProductImg
                  src={pickedVar?.img || pickedProd.img}
                  size={80}
                  alt={pickedProd.name}
                />
                <span className="absolute -bottom-1 -right-1 bg-amber-800 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold shadow-xs">
                  ছবি
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-1">
                  <h4 className="font-black text-sm md:text-base text-stone-900 group-hover:text-amber-950">
                    {pickedProd.name}
                  </h4>
                  <span className="text-sm md:text-base font-black text-amber-950 shrink-0">
                    ৳{pickedProd.sell}
                  </span>
                </div>
                <div className="text-xs text-stone-600 mt-1 flex flex-wrap items-center gap-1.5">
                  <span className="font-bold text-stone-800 bg-white px-2 py-0.5 rounded-md border border-stone-200">
                    {pickedProd.code}
                  </span>
                  <span>{pickedProd.cat}</span>
                  <span
                    className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                      totalQty(pickedProd) <= 0
                        ? "bg-red-100 text-red-700"
                        : "bg-emerald-100 text-emerald-800"
                    }`}
                  >
                    মোট স্টক: {totalQty(pickedProd)} pcs
                  </span>
                </div>
                <div className="mt-2 flex items-center gap-1 text-xs text-amber-900 font-bold group-hover:underline">
                  <span>🔄 ব্যাগ পরিবর্তন করতে চাপুন (সব ছবিসহ ক্যাটালগ)</span>
                  <span className="text-[10px]">▼</span>
                </div>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowProductPicker(true)}
              className="w-full p-4 border-2 border-dashed border-amber-400 rounded-2xl bg-amber-50/70 hover:bg-amber-100/70 text-amber-900 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              👜 ছবিসহ ব্যাগ নির্বাচন করুন (ক্লিক করুন)
            </button>
          )}

          {/* Visual Color Variants with Large 44px Pictures */}
          {pickedProd && (
            <div className="mt-2.5 bg-stone-50/90 p-3 rounded-2xl border border-stone-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-stone-800">
                  কালার নির্বাচন করুন ({pickedProd.variants.length}টি কালার):
                </span>
                {pickedVar && (
                  <span className="text-xs font-black text-amber-950 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-300">
                    নির্বাচিত: {pickedVar.color}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap gap-2.5">
                {pickedProd.variants.map((v) => {
                  const isSelected = v.id === pickVid;
                  const isOut = v.qty <= 0;
                  const varImg = v.img || pickedProd.img;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setPickVid(v.id)}
                      className={`flex items-center gap-2.5 p-1.5 pr-3 rounded-2xl border-2 text-xs font-medium transition-all cursor-pointer text-left ${
                        isSelected
                          ? "border-amber-600 bg-amber-100 ring-2 ring-amber-600 shadow-xs"
                          : isOut
                          ? "border-red-200 bg-red-50 text-red-700"
                          : "border-stone-200 bg-white hover:border-amber-400 hover:bg-amber-50/60 text-stone-800 shadow-2xs"
                      }`}
                    >
                      {varImg ? (
                        <img
                          src={varImg}
                          alt={v.color}
                          className="w-11 h-11 rounded-xl object-cover border-2 border-amber-300 shrink-0 shadow-2xs"
                        />
                      ) : (
                        <span className="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-sm text-stone-600 shrink-0">
                          👜
                        </span>
                      )}
                      <div className="leading-tight">
                        <span className="font-black text-stone-900 block text-xs">
                          {v.color}
                        </span>
                        <span
                          className={`text-[11px] font-black ${
                            isOut ? "text-red-600" : "text-stone-600"
                          }`}
                        >
                          {isOut ? "স্টক শেষ ❌" : `${v.qty} pcs`}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Pricing, Quantity & Add Button */}
          <div className="mt-2.5 flex items-end gap-2">
            <div className="w-28">
              <label className="text-[10px] font-bold text-stone-500 block mb-1">
                দাম (৳)
              </label>
              <input
                type="number"
                placeholder="দাম ৳"
                className="w-full text-xs rounded-xl border border-stone-200 bg-white p-2 font-bold focus:outline-none"
                value={pickPrice}
                onChange={(e) => setPickPrice(e.target.value)}
              />
            </div>
            <div className="w-20">
              <label className="text-[10px] font-bold text-stone-500 block mb-1">
                পরিমাণ
              </label>
              <input
                type="number"
                min={1}
                className="w-full text-xs rounded-xl border border-stone-200 bg-white p-2 font-black text-center focus:outline-none"
                value={pickQty}
                onChange={(e) => setPickQty(Math.max(1, parseInt(e.target.value) || 1))}
              />
            </div>
            <div className="flex-1">
              <Btn small color="amber" onClick={addItem} className="w-full py-2">
                + অর্ডারে যোগ করুন
              </Btn>
            </div>
          </div>

          {/* Selected Items List with Image Thumbnails */}
          {selectedItems.length > 0 && (
            <div className="mt-2.5 space-y-1.5 bg-stone-50 p-2.5 rounded-xl border border-stone-200">
              <span className="text-[11px] font-bold text-stone-600 block">
                অর্ডারের ব্যাগসমূহ ({selectedItems.length}টি)
              </span>
              {selectedItems.map((it, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between text-xs bg-white p-2 rounded-lg border border-stone-200 gap-2"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <ProductImg src={it.img} size={56} alt={it.productName} />
                    <div className="min-w-0 flex-1">
                      <span className="font-bold text-stone-900 block leading-snug">
                        {it.productName}
                      </span>
                      <span className="text-[11px] text-stone-600 block mt-0.5">
                        {it.variantLabel} • <b>{it.qty} পিস</b> = <b>৳{it.price * it.qty}</b>
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(idx)}
                    className="text-stone-400 hover:text-red-600 text-sm ml-2 cursor-pointer p-1"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pricing Summary */}
        <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 flex items-center justify-between">
          <div>
            <div className="text-xs text-stone-500">আইটেম মোট: ৳{itemsTotal} + ডেলিভারি: ৳{dcharge}</div>
            <div className="text-base font-black text-amber-950">
              মোট ক্যাশ কালেকশন (COD): ৳{totalCod}
            </div>
          </div>
          <div className="w-32 text-right">
            <div className="flex items-center justify-end gap-1 mb-0.5">
              <label htmlFor="manual-cod-input" className="text-[10px] font-bold text-stone-600">
                ম্যানুয়াল COD?
              </label>
              {customCod !== "" && (
                <button
                  type="button"
                  onClick={() => setCustomCod("")}
                  className="text-[10px] font-bold text-amber-800 hover:underline cursor-pointer"
                >
                  অটো
                </button>
              )}
            </div>
            <input
              id="manual-cod-input"
              type="number"
              placeholder="যেমন: 1450"
              className="w-full text-xs rounded-lg border border-stone-300 bg-white p-1.5 text-center font-bold focus:outline-none focus:border-amber-600"
              value={customCod}
              onChange={(e) => setCustomCod(e.target.value)}
            />
          </div>
        </div>

        {/* Note */}
        <Field label="ডেলিভারি নোট (স্টেডফাস্ট পার্সেল নোটে যাবে)">
          <input
            className={inputCls}
            placeholder="যেমন: শুক্রবার ডেলিভারি দিতে হবে"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </Field>

        {/* Auto Send to Steadfast Checkbox */}
        <label className="flex items-center gap-2 cursor-pointer bg-amber-50/60 p-2.5 rounded-xl border border-amber-900/15">
          <input
            type="checkbox"
            checked={autoSendSteadfast}
            onChange={(e) => setAutoSendSteadfast(e.target.checked)}
            className="w-4 h-4 text-amber-700 accent-amber-700 rounded"
          />
          <span className="text-xs font-bold text-stone-800">
            🚚 সেভ করার সাথে সাথে স্টেডফাস্টে পার্সেল তৈরি করুন
          </span>
        </label>

        {/* Submit Button */}
        <div className="pt-2">
          <Btn color="amber" onClick={submitOrder} disabled={busy}>
            {busy ? "অর্ডার সেভ হচ্ছে..." : "✅ অর্ডার কনফার্ম করুন"}
          </Btn>
        </div>
      </div>

      {/* Fraud Report Modal */}
      {fraudReport && (
        <Modal title="🛡️ কাস্টমার কুরিয়ার ও ফ্রড রিপোর্ট" onClose={() => setFraudReport(null)}>
          <div className="space-y-3">
            <div
              className="p-3 rounded-xl border text-center"
              style={{
                borderColor: fraudReport.risk_verdict?.color || "#16a34a",
                backgroundColor: `${fraudReport.risk_verdict?.color}15`,
              }}
            >
              <div
                className="text-base font-black"
                style={{ color: fraudReport.risk_verdict?.color || "#16a34a" }}
              >
                {fraudReport.risk_verdict?.label}
              </div>
              <p className="text-xs text-stone-700 mt-1">
                {fraudReport.risk_verdict?.action}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-stone-50 p-2 rounded-xl border">
                <div className="font-bold text-stone-800">{fraudReport.total} টি</div>
                <div className="text-stone-500 text-[10px]">মোট পার্সেল</div>
              </div>
              <div className="bg-emerald-50 p-2 rounded-xl border border-emerald-200">
                <div className="font-bold text-emerald-800">{fraudReport.delivered} টি</div>
                <div className="text-emerald-600 text-[10px]">সফল ডেলিভারি</div>
              </div>
              <div className="bg-red-50 p-2 rounded-xl border border-red-200">
                <div className="font-bold text-red-800">{fraudReport.cancelled} টি</div>
                <div className="text-red-600 text-[10px]">ক্যানসেল/রিটার্ন</div>
              </div>
            </div>

            <div className="text-center font-bold text-xs text-stone-700">
              সামগ্রিক সাকসেস রেট: <span className="text-emerald-700 font-black">{fraudReport.rate}%</span>
            </div>

            <Btn small color="gray" onClick={() => setFraudReport(null)}>
              ঠিক আছে
            </Btn>
          </div>
        </Modal>
      )}

      {/* Visual Product Picker Modal with Search, Photos & Variants */}
      {showProductPicker && (
        <Modal
          title="👜 ছবিসহ ব্যাগ নির্বাচন করুন"
          onClose={() => setShowProductPicker(false)}
        >
          <div className="space-y-3">
            <input
              type="search"
              placeholder="🔍 ব্যাগের নাম বা কোড দিয়ে খুঁজুন..."
              className={inputCls}
              value={pickerSearch}
              onChange={(e) => setPickerSearch(e.target.value)}
              autoFocus
            />

            <div className="space-y-2 max-h-[58vh] overflow-y-auto pr-1">
              {filteredPickerProducts.length === 0 ? (
                <Empty text="কোন ব্যাগ খুঁজে পাওয়া যায়নি" />
              ) : (
                filteredPickerProducts.map((p) => {
                  const isSelected = p.id === pickPid;
                  const stock = totalQty(p);
                  return (
                    <div
                      key={p.id}
                      onClick={() => {
                        setPickPid(p.id);
                        setPickVid(p.variants[0]?.id || "");
                        setPickPrice(p.sell?.toString() || "");
                        setShowProductPicker(false);
                      }}
                      className={`flex items-center gap-3.5 p-3 rounded-2xl border-2 transition-all cursor-pointer ${
                        isSelected
                          ? "border-amber-600 bg-amber-50 ring-2 ring-amber-500 shadow-xs"
                          : "border-stone-200 bg-white hover:border-amber-400 hover:bg-stone-50"
                      }`}
                    >
                      <ProductImg src={p.img} size={72} alt={p.name} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-black text-stone-900 text-sm md:text-base truncate">
                            {p.name}
                          </h4>
                          <span className="font-black text-amber-950 text-sm md:text-base shrink-0">
                            ৳{p.sell}
                          </span>
                        </div>
                        <div className="text-xs text-stone-500 mt-0.5 flex flex-wrap items-center gap-1.5">
                          <span className="font-bold text-stone-700 bg-stone-100 px-2 py-0.5 rounded-md border border-stone-200">
                            {p.code}
                          </span>
                          <span>{p.cat}</span>
                          <span
                            className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                              stock <= 0
                                ? "bg-red-100 text-red-700"
                                : "bg-emerald-100 text-emerald-800"
                            }`}
                          >
                            মোট স্টক: {stock} pcs
                          </span>
                        </div>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {p.variants.map((v) => (
                            <span
                              key={v.id}
                              className="text-xs bg-stone-100 text-stone-700 px-2 py-1 rounded-lg border border-stone-200 flex items-center gap-1.5 font-medium"
                            >
                              {v.img ? (
                                <img
                                  src={v.img}
                                  alt={v.color}
                                  className="w-6 h-6 rounded-md object-cover border border-amber-300 inline"
                                />
                              ) : (
                                <span className="w-6 h-6 rounded-md bg-stone-200 flex items-center justify-center text-[10px]">👜</span>
                              )}
                              <span>{v.color}</span>
                              <b className={v.qty <= 0 ? "text-red-600" : "text-stone-800"}>({v.qty})</b>
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 text-right">
              <Btn small color="gray" onClick={() => setShowProductPicker(false)}>
                বন্ধ করুন
              </Btn>
            </div>
          </div>
        </Modal>
      )}
    </Modal>
  );
}

/* ---------------- Main Orders Tab ---------------- */
export default function OrdersTab() {
  const { db, mutateAndSync, notify } = useShop();
  const { role } = useAuth();
  const isOwner = role === "owner" || role === "admin";

  const [isCreating, setIsCreating] = useState(false);
  const [showQuickReply, setShowQuickReply] = useState(false);
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState<"today" | "yesterday" | "all" | "custom">("today");
  const [customDate, setCustomDate] = useState("");
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);
  const [zoomImg, setZoomImg] = useState<{ src: string; title: string } | null>(null);

  // Filter orders by date & search
  const filteredOrders = useMemo(() => {
    const todayStart = db.salesDay?.start || 0;
    const now = Date.now();
    const oneDayMs = 86400000;

    return (db.orders || []).filter((o) => {
      // 1. Date Filter
      const ots = o.ts || 0;
      if (dateFilter === "today") {
        if (todayStart > 0 && ots < todayStart) return false;
      } else if (dateFilter === "yesterday") {
        if (todayStart > 0) {
          if (ots >= todayStart || ots < todayStart - oneDayMs) return false;
        }
      } else if (dateFilter === "custom" && customDate) {
        const orderDateStr = new Date(ots).toISOString().slice(0, 10);
        if (orderDateStr !== customDate) return false;
      }

      // 2. Search Query
      if (search.trim()) {
        const q = search.toLowerCase();
        const hay = (
          o.id +
          " " +
          o.customer +
          " " +
          o.phone +
          " " +
          o.address +
          " " +
          (o.steadfastId || "") +
          " " +
          (o.trackingCode || "") +
          " " +
          o.items.map((it) => it.productName).join(" ")
        ).toLowerCase();
        if (!hay.includes(q)) return false;
      }

      return true;
    });
  }, [db.orders, db.salesDay?.start, dateFilter, customDate, search]);

  const updateOrderStatus = async (o: Order, newStatus: OrderStatus) => {
    if (newStatus === "Returned" && o.status !== "Returned") {
      if (confirm(`"${o.customer}" এর অর্ডারের ব্যাগগুলো কি স্টকে ফেরত যোগ করবেন?`)) {
        await mutateAndSync((d) => {
          restoreInto(d, o.items);
          const target = d.orders.find((x) => x.id === o.id);
          if (target) {
            target.status = "Returned";
            target.statusTs = Date.now();
          }
          d.moves.unshift({
            id: uid(),
            date: todayBn(),
            text: `↩️ রিটার্ন রিসিভ: অর্ডার ${o.id} এর ব্যাগ স্টকে ফেরত নেওয়া হলো`,
          });
        });
        return;
      }
    }

    await mutateAndSync((d) => {
      const target = d.orders.find((x) => x.id === o.id);
      if (target) {
        target.status = newStatus;
        target.statusTs = Date.now();
      }
    });
  };

  const dispatchToSteadfast = async (o: Order) => {
    if (o.steadfastId) {
      alert(`এই অর্ডারটি ইতিমধ্যে স্টেডফাস্টে পাঠানো হয়েছে (CID: ${o.steadfastId})`);
      return;
    }
    const res = await createParcel(o);
    if (!res) {
      alert("স্টেডফাস্টে পাঠানো যায়নি: " + (steadLastError() || "দয়া করে সেটিংস চেক করুন"));
      return;
    }

    await mutateAndSync((d) => {
      const target = d.orders.find((x) => x.id === o.id);
      if (target) {
        target.steadfastId = res.cid;
        target.trackingCode = res.tracking;
        target.status = "Shipped";
      }
    });

    notify("স্টেডফাস্ট পার্সেল তৈরি!", `${o.customer} এর পার্সেল সফলভাবে স্টেডফাস্টে পাঠানো হয়েছে। CID: ${res.cid}`);
    alert(`✅ স্টেডফাস্ট কুরিয়ারে পার্সেল সফলভাবে বুক হয়েছে!\n\nConsignment ID: ${res.cid}\nTracking Code: ${res.tracking || "N/A"}`);
  };

  const copyFacebookReply = async (o: Order) => {
    const itemsList = o.items.map((it) => `• ${it.productName} (${it.variantLabel}) - ${it.qty} পিস`).join("\n");
    const reply = `প্রিয় ${o.customer},\nআপনার ব্যাগের অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে! 👜✨\n\nঅর্ডার বিবরণ:\n${itemsList}\nমোট প্রদেয় টাকা (COD): ৳${codOf(o)}\nঠিকানা: ${o.address}\n\n${
      o.trackingCode
        ? `স্টেডফাস্ট ট্র্যাকিং কোড: ${o.trackingCode}\nকুরিয়ারের মাধ্যমে ২-৩ দিনের মধ্যে ডেলিভারি পেয়ে যাবেন।`
        : `খুব শীঘ্রই স্টেডফাস্ট কুরিয়ারে আপনার পার্সেল হ্যান্ডওভার করা হবে।`
    }\n\nআমাদের সাথে থাকার জন্য ধন্যবাদ! 💖`;

    try {
      await navigator.clipboard.writeText(reply);
      alert("✅ ফেসবুক রিপ্লাই কপি হয়েছে! মেসেঞ্জারে পাঠিয়ে দিন।");
    } catch {
      prompt("কপি করুন:", reply);
    }
  };

  const deleteOrder = async (o: Order) => {
    if (!confirm(`"${o.customer}" এর অর্ডার ${o.id} মুছে ফেলবেন?`)) return;
    const shouldRestore = confirm("এই অর্ডারের ব্যাগগুলো কি স্টকে ফেরত যোগ করবেন?");
    await mutateAndSync((d) => {
      if (shouldRestore) restoreInto(d, o.items);
      d.orders = d.orders.filter((x) => x.id !== o.id);
      d.moves.unshift({
        id: uid(),
        date: todayBn(),
        text: `🗑️ অর্ডার মুছে ফেলা হলো: ${o.id} (${o.customer})`,
      });
    });
  };

  return (
    <div className="space-y-3 pb-8">
      {/* Top Header */}
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-lg font-black text-stone-900 flex items-center gap-1.5">
          🧾 ফেসবুক অর্ডারসমূহ
        </h2>
        <div className="flex items-center gap-1.5">
          <Btn small color="amber" onClick={() => setIsCreating(true)}>
            + নতুন অর্ডার
          </Btn>
        </div>
      </div>

      {/* Quick Reply Toggle */}
      <button
        onClick={() => setShowQuickReply(!showQuickReply)}
        className="w-full text-xs font-bold py-2 px-3 rounded-xl bg-amber-50 border border-amber-900/15 text-amber-900 flex items-center justify-between cursor-pointer"
      >
        <span>💬 ফেসবুক মেসেঞ্জার কুইক রিপ্লাই জেনারেটর</span>
        <span>{showQuickReply ? "▲ বন্ধ" : "▼ দেখুন"}</span>
      </button>

      {showQuickReply && <QuickReply />}

      {/* Filter Bar */}
      <div className="space-y-2 bg-white p-3 rounded-2xl border border-stone-200 shadow-xs">
        <input
          type="search"
          placeholder="🔍 কাস্টমারের নাম, ফোন, ইনভয়েস বা CID দিয়ে খুঁজুন..."
          className={inputCls}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setDateFilter("today")}
            className={`px-3 py-1.5 rounded-lg font-bold shrink-0 transition-colors cursor-pointer ${
              dateFilter === "today" ? "bg-amber-800 text-white" : "bg-stone-100 text-stone-700 hover:bg-stone-200"
            }`}
          >
            আজ
          </button>
          <button
            onClick={() => setDateFilter("yesterday")}
            className={`px-3 py-1.5 rounded-lg font-bold shrink-0 transition-colors cursor-pointer ${
              dateFilter === "yesterday" ? "bg-amber-800 text-white" : "bg-stone-100 text-stone-700 hover:bg-stone-200"
            }`}
          >
            গতকাল
          </button>
          <button
            onClick={() => setDateFilter("all")}
            className={`px-3 py-1.5 rounded-lg font-bold shrink-0 transition-colors cursor-pointer ${
              dateFilter === "all" ? "bg-amber-800 text-white" : "bg-stone-100 text-stone-700 hover:bg-stone-200"
            }`}
          >
            সব অর্ডার ({db.orders.length})
          </button>
          <button
            onClick={() => setDateFilter("custom")}
            className={`px-3 py-1.5 rounded-lg font-bold shrink-0 transition-colors cursor-pointer ${
              dateFilter === "custom" ? "bg-amber-800 text-white" : "bg-stone-100 text-stone-700 hover:bg-stone-200"
            }`}
          >
            তারিখ
          </button>
        </div>

        {dateFilter === "custom" && (
          <input
            type="date"
            className={inputCls}
            value={customDate}
            onChange={(e) => setCustomDate(e.target.value)}
          />
        )}
      </div>

      {/* Orders List */}
      {filteredOrders.length === 0 ? (
        <Empty text="কোন অর্ডার খুঁজে পাওয়া যায়নি" />
      ) : (
        <div className="space-y-3">
          {filteredOrders.map((o) => (
            <Card key={o.id} className="relative">
              {/* Order Header */}
              <div className="flex items-start justify-between gap-2 border-b border-stone-100 pb-2.5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-stone-900 text-sm">{o.customer}</span>
                    <Badge status={o.status} />
                  </div>
                  <div className="text-xs text-stone-500 mt-0.5 flex items-center gap-2">
                    <a
                      href={`tel:${o.phone}`}
                      className="font-bold text-amber-900 hover:underline"
                    >
                      📞 {o.phone}
                    </a>
                    <span>• {zoneName(o.zone)}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-base font-black text-amber-950">৳{codOf(o)}</div>
                  <span className="text-[10px] text-stone-400">{o.id}</span>
                </div>
              </div>

              {/* Address */}
              <div className="py-2 text-xs text-stone-700">
                <span className="font-bold text-stone-500">ঠিকানা:</span> {o.address}
                {o.note && (
                  <div className="mt-1 text-[11px] text-amber-800 bg-amber-50 p-1.5 rounded-lg">
                    📝 নোট: {o.note}
                  </div>
                )}
              </div>

              {/* Items List with Large Click-to-Zoom Photo Thumbnail */}
              <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200 text-xs space-y-2 my-1.5">
                {o.items.map((it, idx) => {
                  const fallbackProd = db.products.find((p) => p.id === it.productId);
                  const fallbackVar = fallbackProd?.variants.find((v) => v.id === it.variantId);
                  const itemImg = it.img || fallbackVar?.img || fallbackProd?.img;
                  return (
                    <div
                      key={idx}
                      className="flex justify-between items-center gap-3 bg-white p-2 rounded-xl border border-stone-200/80 shadow-2xs"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        {itemImg ? (
                          <button
                            type="button"
                            onClick={() =>
                              setZoomImg({
                                src: itemImg,
                                title: `${it.productName} (${it.variantLabel})`,
                              })
                            }
                            aria-label={`${it.productName} এর ছবি বড় করে দেখুন`}
                            title="ছবি বড় করে দেখতে চাপুন"
                            className="relative shrink-0 rounded-xl overflow-hidden border-2 border-stone-200 hover:border-amber-500 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-600"
                          >
                            <ProductImg src={itemImg} size={72} alt={it.productName} />
                            <span className="absolute bottom-1 right-1 bg-stone-900/75 text-white rounded px-1 py-0.5 text-[9px] font-bold leading-none">
                              🔍
                            </span>
                          </button>
                        ) : (
                          <div className="shrink-0">
                            <ProductImg src={itemImg} size={72} alt={it.productName} />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="font-black text-stone-900 text-xs sm:text-sm leading-snug">
                            {it.productName}
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-1.5">
                            <span className="bg-amber-50 text-amber-900 border border-amber-200/80 px-2 py-0.5 rounded-md text-[11px] font-bold">
                              {it.variantLabel}
                            </span>
                            <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded-md text-[11px] font-black">
                              {it.qty} পিস
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-black text-amber-950 text-sm">
                          ৳{it.price * it.qty}
                        </div>
                        {it.qty > 1 && (
                          <div className="text-[10px] text-stone-500 font-semibold">
                            @৳{it.price}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Steadfast CID / Status line */}
              <div className="mt-2 flex items-center justify-between text-xs bg-stone-100/70 p-2 rounded-xl">
                <div>
                  {o.steadfastId ? (
                    <span className="font-bold text-purple-900">
                      CID: <code className="bg-white px-1.5 py-0.5 rounded border border-purple-200">{o.steadfastId}</code>
                    </span>
                  ) : (
                    <span className="text-stone-500">স্টেডফাস্ট পার্সেল তৈরি হয়নি</span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Status Dropdown */}
                  <select
                    className="text-xs rounded-lg border border-stone-300 bg-white p-1 font-bold focus:outline-none"
                    value={o.status}
                    onChange={(e) => updateOrderStatus(o, e.target.value as OrderStatus)}
                  >
                    {ALL_STATUS.map((st) => (
                      <option key={st} value={st}>
                        {BN_STATUS[st]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Action Buttons Bar */}
              <div className="mt-2.5 flex items-center justify-between gap-1.5 border-t border-stone-100 pt-2 text-xs">
                <div className="flex items-center gap-1">
                  {!o.steadfastId && (
                    <Btn small color="green" onClick={() => dispatchToSteadfast(o)}>
                      🚚 স্টেডফাস্টে পাঠান
                    </Btn>
                  )}
                  {o.steadfastId && (
                    <Btn small color="blue" onClick={() => setTrackingOrder(o)}>
                      🔍 Live Track
                    </Btn>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <Btn small color="gray" onClick={() => copyFacebookReply(o)}>
                    💬 রিপ্লাই কপি
                  </Btn>
                  {isOwner && (
                    <button
                      onClick={() => deleteOrder(o)}
                      className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg cursor-pointer"
                      title="অর্ডার মুছুন"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Create Order Modal */}
      {isCreating && <CreateOrderModal onClose={() => setIsCreating(false)} />}

      {/* Live Tracking Modal */}
      {trackingOrder && (
        <Modal
          title={`🚚 স্টেডফাস্ট লাইভ ট্র্যাকিং (${trackingOrder.id})`}
          onClose={() => setTrackingOrder(null)}
        >
          <div className="space-y-3">
            <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs">
              <div><b>কাস্টমার:</b> {trackingOrder.customer} ({trackingOrder.phone})</div>
              <div><b>ঠিকানা:</b> {trackingOrder.address}</div>
              <div><b>Consignment ID:</b> {trackingOrder.steadfastId}</div>
              <div><b>ট্র্যাকিং কোড:</b> {trackingOrder.trackingCode || "N/A"}</div>
            </div>

            <div className="border-l-2 border-amber-700 pl-4 space-y-3 py-1">
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-amber-700"></div>
                <div className="text-xs font-bold text-stone-900">পার্সেল পিকআপ সম্পন্ন হয়েছে</div>
                <div className="text-[10px] text-stone-500">স্টেডফাস্ট হাব কর্তৃক রিসিভড</div>
              </div>
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-blue-600"></div>
                <div className="text-xs font-bold text-stone-900">গন্তব্যের হাবে ইন-ট্রানজিট</div>
                <div className="text-[10px] text-stone-500">ডেলিভারি রাইডারের নিকট প্রেরিত</div>
              </div>
              <div className="relative">
                <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-stone-300"></div>
                <div className="text-xs font-bold text-stone-500">ডেলিভারি ও ক্যাশ কালেকশন</div>
                <div className="text-[10px] text-stone-400">প্রক্রিয়াধীন</div>
              </div>
            </div>

            <Btn small color="gray" onClick={() => setTrackingOrder(null)}>
              বন্ধ করুন
            </Btn>
          </div>
        </Modal>
      )}

      {/* Order Bag Image Zoom Lightbox Modal */}
      {zoomImg && (
        <Modal title={zoomImg.title} onClose={() => setZoomImg(null)}>
          <div className="flex flex-col items-center p-2">
            <img
              src={zoomImg.src}
              alt={zoomImg.title}
              className="max-h-[65vh] w-auto max-w-full rounded-2xl object-contain border border-stone-200 shadow-lg bg-white"
            />
            <div className="mt-4 text-center">
              <Btn small color="gray" onClick={() => setZoomImg(null)}>
                বন্ধ করুন
              </Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
